#include<bits/stdc++.h>
using namespace std;

int main(){
    map<int, char> mp;
    mp.insert(make_pair(0, 'z'));
    mp.insert(make_pair(1, 'a'));
    mp.insert(make_pair(2, 'y'));
    mp.insert(make_pair(3, 'b'));
    mp.insert(make_pair(4, 'x'));
    mp.insert(make_pair(5, 'c'));
    mp.insert(make_pair(6, 'w'));
    mp.insert(make_pair(7, 'd'));
    mp.insert(make_pair(8, 'v'));
    mp.insert(make_pair(9, 'e'));
    mp.insert(make_pair(10, 'u'));
    mp.insert(make_pair(11, 'f'));
    mp.insert(make_pair(12, 't'));
    mp.insert(make_pair(13, 'g'));
    mp.insert(make_pair(14, 's'));
    mp.insert(make_pair(15, 'h'));
    mp.insert(make_pair(16, 'r'));
    mp.insert(make_pair(17, 'i'));
    mp.insert(make_pair(18, 'q'));
    mp.insert(make_pair(19, 'j'));
    mp.insert(make_pair(20, 'p'));
    mp.insert(make_pair(21, 'k'));
    mp.insert(make_pair(22, 'o'));
    mp.insert(make_pair(23, 'l'));
    mp.insert(make_pair(24, 'n'));
    mp.insert(make_pair(25, 'm'));


    string input, cipherText = "";
    cout << "Enter a Sentence is lowercase: ";
    cin >> input;

    for(auto j: input){
        for (auto i = mp.begin(); i != mp.end(); i++){
            int temp = j - 97;
            if(temp==i->first){
                cipherText += i->second;
            }
        }
    }

    cout << "Cipher Text: " << cipherText << endl;
    return 0;
}
